import books from "./Books";
import { combineReducers } from "redux";
const reducer = combineReducers({
  books
});
export default reducer;
